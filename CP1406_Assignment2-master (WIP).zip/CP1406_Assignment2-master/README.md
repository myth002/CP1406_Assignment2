Github repository for Group 3, CP1406 - Assignment 2
